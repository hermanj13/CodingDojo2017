FactoryGirl.define do
  factory :message do
    message "MyText"
    user nil
  end
end
