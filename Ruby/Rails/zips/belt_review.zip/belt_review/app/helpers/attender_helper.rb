module AttenderHelper
end
