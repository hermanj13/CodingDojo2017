require 'rails_helper'

RSpec.describe DiscussionsController, type: :controller do

end
