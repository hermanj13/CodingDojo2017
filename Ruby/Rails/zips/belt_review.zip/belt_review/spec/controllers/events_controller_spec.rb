require 'rails_helper'

RSpec.describe EventsController, type: :controller do

end
