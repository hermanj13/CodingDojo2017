require 'rails_helper'

RSpec.describe AttenderController, type: :controller do

end
