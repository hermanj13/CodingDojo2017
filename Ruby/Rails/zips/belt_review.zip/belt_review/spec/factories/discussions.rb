FactoryGirl.define do
  factory :discussion do
    message "MyText"
    user nil
    event nil
  end
end
