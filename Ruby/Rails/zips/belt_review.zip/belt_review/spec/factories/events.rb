FactoryGirl.define do
  factory :event do
    name ""
    date ""
    city ""
    state "MyString"
  end
end
