FactoryGirl.define do
  factory :attender do
    user nil
    event nil
  end
end
