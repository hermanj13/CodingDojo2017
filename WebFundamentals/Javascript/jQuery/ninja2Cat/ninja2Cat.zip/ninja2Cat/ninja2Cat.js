$(document).ready(function() {

    $(".img1").click(function(event) {
        $(this).attr('src', 'cat0.png');
    });

    $(".img2").click(function(event) {
        $(this).attr('src', 'cat1.png');
    });

    $(".img3").click(function(event) {
        $(this).attr('src', 'cat2.png');
    });

    $(".img4").click(function(event) {
        $(this).attr('src', 'cat3.png');
    });

    $(".img5").click(function(event) {
        $(this).attr('src', 'cat4.png');
    });

});
