var math = require('./mathlib')();

console.log(math.add(5, 3))
console.log(math.multiply(5, 3))
console.log(math.square(55))
console.log(math.random(1, 35))
