app.controller('editController', ['$scope', '$routeParams', function($scope, $routeParams) {
    console.log('editController loaded');
    console.log("$routeParams currently looks like this:", $routeParams);
}]);
