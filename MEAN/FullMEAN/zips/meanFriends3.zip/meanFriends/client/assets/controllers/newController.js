app.controller('newController', ['$scope', function($scope) {
    $scope.createFriend = function() {
        console.log($scope.newFriend);
        $scope.newFriend = {};
    }
}]);
