$(document).ready(function() {
    $("#theButton").click(function() {
        $(this).toggleClass("click")
    })
});
